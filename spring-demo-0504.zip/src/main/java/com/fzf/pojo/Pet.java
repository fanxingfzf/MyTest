package com.fzf.pojo;

/**
 * @author
 * @Data:2022/4/27 21:33
 * @description:some description
 * @Function:
 */
public abstract class Pet {
    /**
     * shout()动物叫法
     */
    public abstract void shout();

}
